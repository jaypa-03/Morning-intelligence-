# Morning Intelligence starter

A mobile-first Next.js dashboard for Singapore and Seoul weather, topic-grouped global news, and clearly labelled pending market/economic modules.

**This is starter source code, not a deployed or connected service.** It contains no credentials or API keys.

## Accounts
- GitHub: https://github.com/signup
- Supabase: https://supabase.com/dashboard
- Vercel: https://vercel.com/signup

## 1. Create the GitHub repository
Create a **private** repository named `morning-intelligence`. Upload the contents of this folder to its root. Do not upload `.env` files or secrets.

## 2. Create Supabase project and table
Create a project at https://database.new (Singapore region if available). Open SQL Editor and run `supabase/migrations/0001_briefing_snapshots.sql`. The table has public read-only RLS access; browser clients cannot insert or update records.

From Project Settings → API, copy the Project URL and publishable/anon key. Never expose the service-role key to the browser.

## 3. Deploy to Vercel
Import the GitHub repository at https://vercel.com/new. Select Next.js. Add these environment variables:
- `NEXT_PUBLIC_SUPABASE_URL` = Supabase Project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` = Supabase publishable/anon key

Deploy. Vercel provides a free `*.vercel.app` address. No custom domain is required initially.

## 4. Deploy the Edge Function
Install Node.js LTS and Supabase CLI using https://supabase.com/docs/guides/local-development/cli/getting-started. In this project folder run:

```bash
npm install
npm run dev
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set REFRESH_SECRET="YOUR_LONG_RANDOM_SECRET"
supabase functions deploy daily-refresh --no-verify-jwt
```

Keep the secret in a password manager. The Supabase Edge Function runtime supplies `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`; do not copy the service-role key into Vercel or client code.

## 5. Test first run
Invoke the `daily-refresh` Edge Function with POST, header `x-refresh-secret: YOUR_LONG_RANDOM_SECRET`, and body `{}`. Or:

```bash
curl -X POST "https://YOUR_PROJECT_REF.supabase.co/functions/v1/daily-refresh" \
  -H "Content-Type: application/json" \
  -H "x-refresh-secret: YOUR_LONG_RANDOM_SECRET" -d "{}"
```

A successful response has `ok: true`. Reload the Vercel site. Review Edge Function logs if it fails.

## 6. Schedule daily at 07:00 Singapore time
Singapore is UTC+8 year-round. For a UTC scheduler, 07:00 SGT is 23:00 UTC on the previous day (`0 23 * * *`). Enable `pg_cron` and `pg_net` in Supabase Database → Extensions. Store the function secret and project URL in Supabase Vault, then create a cron job from SQL Editor:

```sql
select cron.schedule(
  'morning-intelligence-0700-sgt',
  '0 23 * * *',
  $$
  select net.http_post(
    url := (select decrypted_secret from vault.decrypted_secrets where name = 'project_url') || '/functions/v1/daily-refresh',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'x-refresh-secret',(select decrypted_secret from vault.decrypted_secrets where name = 'morning_refresh_secret')
    ),
    body := '{}'::jsonb
  );
  $$
);
```

Create Vault secrets named `project_url` and `morning_refresh_secret` first. One way is to run these statements in SQL Editor, replacing the values with your own:

```sql
select vault.create_secret('https://YOUR_PROJECT_REF.supabase.co', 'project_url');
select vault.create_secret('YOUR_LONG_RANDOM_SECRET', 'morning_refresh_secret');
```

Verify Cron run history and the timezone before relying on the schedule. Do not also create a second 07:00 local-time schedule.

## Data source and licensing notes
- Weather: Open-Meteo https://open-meteo.com/en/docs and terms https://open-meteo.com/en/terms. Review attribution and current usage terms.
- News: GDELT https://www.gdeltproject.org/. This implementation links to publisher pages; verify stories with original publishers.
- US macro: FRED API https://fred.stlouisfed.org/docs/api/fred/ (requires API key; not yet integrated).
- Market data: intentionally not integrated. Confirm exchange coverage, delayed/live status and external display/redistribution permissions before selecting a provider.

## Production considerations
Add retries, alerting, stale-data thresholds, rate limiting, manual admin refresh and monitoring before treating this as a critical operational information service. Free plans may have inactivity, resource, backup and uptime limitations.
