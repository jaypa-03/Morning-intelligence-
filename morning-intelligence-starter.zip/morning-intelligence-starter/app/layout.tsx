import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Morning Intelligence', description: 'Daily briefing for Singapore, Seoul and global markets.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
